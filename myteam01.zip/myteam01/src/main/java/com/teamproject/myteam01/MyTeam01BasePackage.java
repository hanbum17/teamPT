package com.teamproject.myteam01;

public interface MyTeam01BasePackage {
}
