package com.teamproject.myteam01.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.teamproject.myteam01.domain.EventReviewVO;
import com.teamproject.myteam01.domain.EventVO;
import com.teamproject.myteam01.domain.RestaurantsReviewVO;
import com.teamproject.myteam01.mapper.EventMapper;

import lombok.RequiredArgsConstructor;


@Service
@RequiredArgsConstructor
public class EventServiceImpl implements EventService{

	private final EventMapper eventMapper ;
	
	//록귀
	@Override
	public EventVO eventDetail(Long eno) {
		return eventMapper.eventDetail(eno);
	}
	
	@Override
	public List<EventReviewVO> selectReviews(Long eno, int pageNum) {
		return eventMapper.selectReviews(eno, pageNum);

	}
	
	//리뷰 가져오기 및 리뷰 갯수와 평균점수 구하기
	@Override
	public List<EventReviewVO> selectReviews2(Long eno) {
		List<EventReviewVO> reviews = eventMapper.selectReviews2(eno);
		Long count =0L;
		Long erRating = 0L;
		EventReviewVO setRatingAverage = new EventReviewVO();
		if(reviews != null) {
			for(int i = 0 ; i <= reviews.size(); i++) {
				EventReviewVO getReviews = reviews.get(i);
				erRating += getReviews.getErrating();
				count += i ;
			}
			float ratingAverage = erRating/count;
			setRatingAverage.setErCount(count);
			setRatingAverage.setRatingAverage(ratingAverage);
			
		}
		
		return reviews;
	}
	
	
	@Override
	public int registerReview(EventReviewVO eventReviewVO) {
		return eventMapper.registerReview(eventReviewVO);
	}
	
	@Override
	public int copyReview(Long erno) {
		return eventMapper.copyReview(erno);
	}

	@Override
	public int deleteReview(Long erno) {
		return eventMapper.deleteReview(erno);
	}

	@Override
	public void updateEventCoord(EventVO event) {
		eventMapper.updateEventCoord(event);
	}
	
	@Override
	public List<String> selectEHOST(){
		return eventMapper.selectEHOST();
	}

	

	//희준
	//행사 목록
	@Override
	public List<EventVO> eventList(){
		List<EventVO> event = eventMapper.selectEventList();
		return event;
	}
	
	//행사 등록
	@Override
	public Long regiEvent(EventVO event) {
		eventMapper.registerEvent(event);
		return event.getEno();
	}
	
	//행사 조회
	@Override
	public EventVO getEvent(Long eno) {
		EventVO event = eventMapper.selectEvent(eno);
		eventMapper.updateEviewsCnt(eno);
		return event ;
	}
	
	
	//행사 수정
	@Override
	public boolean modifyEvent(EventVO event) {
		return eventMapper.updateEvent(event) == 1;
	}
	
	//행사 삭제
	@Override
	public boolean removeEvent(Long eno) {
		return eventMapper.delEvent(eno) == 1;
		
	}
	
}
