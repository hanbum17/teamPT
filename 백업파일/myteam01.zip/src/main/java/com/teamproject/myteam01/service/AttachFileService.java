package com.teamproject.myteam01.service;

import java.util.List;

import com.teamproject.myteam01.domain.AttachFileDTO;

public interface AttachFileService {


	public List<AttachFileDTO> getAllFiles(String uno);
	
	public AttachFileDTO getFile(String uuid);

	
}
